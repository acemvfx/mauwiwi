package com.accenture.tcf.bars.file;

import java.io.File;

import org.apache.log4j.Logger;

public abstract class AbstractInputFile implements IInputFile{
	
	private File file;
	
	protected Logger logger = Logger.getLogger(AbstractInputFile.class);
	
	@Override
	public void setFile(File file) {
		this.file = file;
	}

	@Override
	public File getFile() {
		// TODO Auto-generated method stub
		return file;
	}
}
