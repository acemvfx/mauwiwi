package com.accenture.tcf.bars.file;

import java.io.File;

import org.apache.log4j.Logger;

public abstract class AbstractOutputFile implements IOutputFile {
	
	private File file;
	
	protected Logger logger = Logger.getLogger(AbstractOutputFile.class);
	
	@Override
	public void setFile(File file) {
		this.file = file;
	}

	@Override
	public File getFile() {
		return file;
	}
}
