package com.accenture.tcf.bars.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="account_id")
	private int accountId;
	
	@Column(name="account_name")
	private String accountName;
	
	@Column(name="date_created")
	private Date dateCreated;
	
	@Column(name="is_active")
	private String isActive;
	
	@Column(name="last_edited")
	private String lastEdited;
	
	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customerId;
	
	public Account() {}
}
