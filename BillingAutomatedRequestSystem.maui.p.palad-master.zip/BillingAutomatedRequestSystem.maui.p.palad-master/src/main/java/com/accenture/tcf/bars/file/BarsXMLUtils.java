package com.accenture.tcf.bars.file;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.accenture.sef.xml.impl.BarsWriteXmlUtils;
import com.accenture.sef.xml.interfce.BarsWriteXMLUtilsInterface;
import com.accenture.tcf.bars.domain.Record;
import com.accenture.tcf.bars.exception.BarsException;

public class BarsXMLUtils {
	
	private Logger logger = Logger.getLogger(BarsWriteXmlUtils.class);
	
	public void writeXML (List<Record> records) throws BarsException {
		BarsWriteXMLUtilsInterface x = new BarsWriteXmlUtils();
		String outputFilePath = FileConstants.outputReportDirectory;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat fileNameDateFormatter = new SimpleDateFormat("MMddyyyy_HHmmss");
		String finalFileName = outputFilePath+FileConstants.reportFileName+fileNameDateFormatter.format(new Date())+FileConstants.reportFileExt;
		
		Document doc = x.createXMLDocument();
		Element rootElement = x.createDocumentElement(doc, "BARS");
		records.stream().forEach( record -> {
			Element recordElement = x.createChildElement(doc, rootElement, "request");
			x.createElementTextNode(doc, recordElement, "billing-cycle", Integer.toString(record.getBillingCycle()));
			x.createElementTextNode(doc, recordElement, "start-date", formatter.format(record.getStartDate()));
			x.createElementTextNode(doc, recordElement, "end-date", formatter.format(record.getEndDate()));
			x.createElementTextNode(doc, recordElement, "first-name", record.getFirstName());
			x.createElementTextNode(doc, recordElement, "last-name", record.getLastName());
			x.createElementTextNode(doc, recordElement, "amount", Double.toString(record.getAmount()));
		});
		
		File file = new File(finalFileName);
		try {
			if(file.createNewFile()) {
				//System.out.println("File created");
			}
		} catch (IOException e) {
			logger.info(BarsException.PATH_DOES_NOT_EXIST);
			throw new BarsException(BarsException.PATH_DOES_NOT_EXIST);
		}
		
		x.transformToXML(doc, finalFileName);
	}
}
