package com.accenture.tcf.bars.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="billing")
public class Billing {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="billing_id")
	private int billingId;
	
	@Column(name="billing_cycle")
	private int billingCycle;
	
	@Column(name="billing_month")
	private String billingMonth;
	
	@Column(name="amount")
	private double amount;
	
	@Column(name="start_date")
	private Date startDate;
	
	@Column(name="end_date")
	private Date endDate;
	
	@Column(name="last_edited")
	private String lastEdited;
	
	@ManyToOne
	@JoinColumn(name="account_id")
	private Account accountId;
	
	public Billing() {}
	
}
