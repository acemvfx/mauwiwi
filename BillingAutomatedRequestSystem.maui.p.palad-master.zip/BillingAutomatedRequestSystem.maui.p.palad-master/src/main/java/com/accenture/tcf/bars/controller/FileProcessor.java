package com.accenture.tcf.bars.controller;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.tcf.bars.dao.IRecordDAO;
import com.accenture.tcf.bars.dao.IRequestDAO;
import com.accenture.tcf.bars.domain.Record;
import com.accenture.tcf.bars.domain.Request;
import com.accenture.tcf.bars.exception.BarsException;
import com.accenture.tcf.bars.factory.InputFileFactory;
import com.accenture.tcf.bars.file.IInputFile;
import com.accenture.tcf.bars.file.IOutputFile;
import com.accenture.tcf.bars.file.XMLOutputFileImpl;

public class FileProcessor {

	private IRequestDAO requestDAO;
	private IRecordDAO recordDAO;
	private IInputFile inputFile;
	private IOutputFile outputFile;
	private Logger logger = Logger.getLogger(FileProcessor.class);
	
	public FileProcessor(IRequestDAO requestDAO, IRecordDAO recordDAO) {
		this.requestDAO = requestDAO;
		this.recordDAO = recordDAO;
		outputFile = new XMLOutputFileImpl();
	}
	
	public void execute(String filePath) throws Exception {
		InputFileFactory inputFileFactory = InputFileFactory.GetInstance();
		inputFile = inputFileFactory.getInputFile(new File(filePath));
		
		if(inputFile == null) {
			logger.info(BarsException.NO_SUPPORTED_FILE);
			throw new BarsException(BarsException.NO_SUPPORTED_FILE);
		}
		
		List<Request> reqList = inputFile.readFile();
		
		reqList.stream().forEach( request -> requestDAO.insertRequest(request) );
		List<Record> recordsList = recordDAO.retrieveRecords();
		
		if(recordsList.isEmpty()) {
			logger.info(BarsException.NO_RECORDS_TO_WRITE);
			throw new BarsException(BarsException.NO_RECORDS_TO_WRITE);
		}
	}
	
	public List<Record> retrieveRecordFromDB(){
		return recordDAO.retrieveRecords();
	}
	
	public void writeOutput(List<Record> records) throws BarsException {
    	outputFile.writeFile(records);
	}
	
}
