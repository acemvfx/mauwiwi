package com.accenture.tcf.bars.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.accenture.tcf.bars.domain.Request;
import com.accenture.tcf.bars.exception.BarsException;

public class CSVInputFileImpl extends AbstractInputFile {

	@Override
	public List<Request> readFile() throws BarsException {
		List<Request> listOfRequests = new ArrayList<>();
		String line = "";
		int rowCounter = 1;
		File file = getFile();
		int billingCycle;
		Date startDate;
		Date endDate;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		formatter.setLenient(false);
		String parsedLineArray[] = null;
		
		if(!file.canRead() || file.length() == 0) {
			logger.info(BarsException.NO_RECORDS_TO_READ);
			throw new BarsException(BarsException.NO_RECORDS_TO_READ);
		}
		
		try (BufferedReader br = new BufferedReader(new FileReader( file ))) {
	        while ((line = br.readLine()) != null) {
	            // 010101201401312014
	        	parsedLineArray = line.trim().split(",");
	        	
	        	billingCycle = Integer.parseInt(parsedLineArray[0]);
	        	if(billingCycle < 1 || billingCycle > 12) {
	        		logger.error(BarsException.BILLING_CYCLE_NOT_ON_RANGE + rowCounter);
	        		throw new BarsException(BarsException.BILLING_CYCLE_NOT_ON_RANGE + rowCounter);
	        	}

	        	try {
	        		startDate = formatter.parse(parsedLineArray[1]);
	        	}catch(ParseException e) {
	        		logger.error(BarsException.INVALID_START_DATE_FORMAT + rowCounter);
	        		throw new BarsException(BarsException.INVALID_START_DATE_FORMAT + rowCounter);
	        	}
	        	
	        	try {
	        		endDate = formatter.parse(parsedLineArray[2]);
	        	}catch(ParseException e) {
	        		logger.error(BarsException.INVALID_END_DATE_FORMAT + rowCounter);
	        		throw new BarsException(BarsException.INVALID_END_DATE_FORMAT + rowCounter);
	        	}
	        	
	        	listOfRequests.add(new Request(billingCycle, startDate, endDate));
	        	rowCounter++;
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
		return listOfRequests;
	}

}
