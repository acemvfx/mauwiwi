package com.accenture.tcf.bars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarsApp {

	public static void main(String[] args) {
		SpringApplication.run(BarsApp.class, args);
	}

}
