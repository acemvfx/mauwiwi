package com.accenture.tcf.bars.dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.tcf.bars.domain.Record;

@Repository
public class RecordDAOImpl implements IRecordDAO {
	
	@Autowired
	private EntityManager entityManager;
	
	public RecordDAOImpl() {
		
	}

	@Override
	@Transactional
	public List<Record> retrieveRecords() {
		Session currentSession = entityManager.unwrap(Session.class);
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("Select bill.billingCycle, bill.startDate, bill.endDate, cust.firstName, cust.lastName, bill.amount ");
		sbQuery.append("FROM Billing bill ");
		sbQuery.append("INNER JOIN Account acc ON bill.accountId = acc.accountId ");
		sbQuery.append("INNER JOIN Customer cust ON acc.customerId = cust.customerId ");
		sbQuery.append("WHERE EXISTS (Select 1 from Request req where req.billingCycle = bill.billingCycle AND req.startDate = bill.startDate AND req.endDate = bill.endDate) ");
		
		List<Object[]> results = currentSession.createQuery(sbQuery.toString(), Object[].class).getResultList();		
		List<Record> retrievedRecords = results.stream()
				.map(resultObject -> new Record( (int)resultObject[0], (Date)resultObject[1], (Date)resultObject[2], (String)resultObject[3], (String)resultObject[4], (double)resultObject[5] ))
				.collect(Collectors.toList());
		
		return retrievedRecords;
	}

}
