package com.accenture.tcf.bars.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.tcf.bars.dao.IRecordDAO;
import com.accenture.tcf.bars.dao.IRequestDAO;
import com.accenture.tcf.bars.domain.Record;
import com.accenture.tcf.bars.exception.BarsException;
import com.accenture.tcf.bars.file.FileConstants;

@Controller
public class BarsController {
	
	public Logger logger = Logger.getLogger(BarsController.class);
	
	@Autowired 
	IRequestDAO requestDAO;
	
	@Autowired
	IRecordDAO recordDAO;
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	
	@PostMapping("/process.htm")
	public ModelAndView execute( @RequestParam("file")  MultipartFile file ) {
		ModelAndView mv = new ModelAndView();
		
		FileProcessor fileProcessor = new FileProcessor(requestDAO, recordDAO);
		try {
			String tmpFilePath = validateDirectory(file);
			fileProcessor.execute(tmpFilePath);
			
			List<Record> listOfRecords = fileProcessor.retrieveRecordFromDB();
			mv.setViewName("/success");
			mv.addObject("records", listOfRecords);
			requestDAO.deleteRequest();
			fileProcessor.writeOutput(listOfRecords);			
			
		} catch (Exception e) {
			mv.addObject("errorMessage", e.getMessage());
			mv.setViewName("error");
		}finally {
			File tmpDirectory = new File(FileConstants.outputDirectory + "tmp");
			if(tmpDirectory.exists()) {
				deleteTmpDirectory(tmpDirectory);
			}
		}
		return mv;

	}
	
	private void deleteTmpDirectory(File file) {
		if(file.isDirectory()){
    		//directory is empty, then delete it
    		if(file.list().length==0){
    		   file.delete();

    		}else{

    		   //list all the directory contents
        	   String files[] = file.list();

        	   for (String temp : files) {
        	      //construct the file structure
        	      File fileDelete = new File(file, temp);
        	      //recursive delete
        	      deleteTmpDirectory(fileDelete);
        	   }
        	   //check the directory again, if empty then delete it
        	   if(file.list().length==0){
           	     file.delete();
        	   }
    		}
    	}else{
    		file.delete();
    	}
	}
	
	private String validateDirectory(MultipartFile file) throws BarsException {
		File outputDirectory = new File(FileConstants.outputDirectory);
		String tmpFilePath = "";
		if( outputDirectory.exists() && outputDirectory.isDirectory() ) {
			
			String tmpDirectoryPath = outputDirectory.getAbsolutePath().concat("\\tmp");
			
			//Creating a File object
		    File tmpDirectory = new File(tmpDirectoryPath);
		     
		    //Creating the directory
		    boolean bool = tmpDirectory.mkdir();
		     
		    if(bool) {
		    	tmpFilePath = tmpDirectoryPath + System.getProperty("file.separator") + file.getOriginalFilename();
				try {
					file.transferTo(new File(tmpFilePath));
				} catch (IllegalStateException | IOException e) {
					logger.info(BarsException.PATH_DOES_NOT_EXIST);
					throw new BarsException(BarsException.PATH_DOES_NOT_EXIST);
				}
		    }
		    else {
		    	logger.info(BarsException.PATH_DOES_NOT_EXIST);
		    	throw new BarsException(BarsException.PATH_DOES_NOT_EXIST);
		    }
		     
		}else {
			logger.info(BarsException.PATH_DOES_NOT_EXIST);
			throw new BarsException(BarsException.PATH_DOES_NOT_EXIST);
		}
		
		return tmpFilePath;
	}
	
	
}
