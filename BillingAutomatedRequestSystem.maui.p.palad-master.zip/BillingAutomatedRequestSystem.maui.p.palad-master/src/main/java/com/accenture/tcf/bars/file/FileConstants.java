package com.accenture.tcf.bars.file;

public class FileConstants {
	
	public static final String outputDirectory = "C:\\BARS\\";
	
	public static final String outputReportDirectory = outputDirectory + "Report\\";
	
	public static final String reportFileName = "BARS_Report-";
	
	public static final String reportFileExt = ".xml";
}
