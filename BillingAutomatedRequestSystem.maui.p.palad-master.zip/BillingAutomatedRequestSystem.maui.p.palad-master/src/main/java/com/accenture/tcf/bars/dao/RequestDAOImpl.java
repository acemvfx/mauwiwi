package com.accenture.tcf.bars.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.tcf.bars.domain.Request;

@Repository
public class RequestDAOImpl implements IRequestDAO {

	@Autowired
	private EntityManager entityManager;
	
	public RequestDAOImpl() {
		
	}


	@Override
	@Transactional
	public void insertRequest(Request request) {
		Session currentSession = entityManager.unwrap(Session.class);
		request.setRequestId(0);
		currentSession.save(request);
	}

	@Override
	@Transactional
	public void deleteRequest() {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.createQuery("DELETE FROM Request").executeUpdate();
	}

}
