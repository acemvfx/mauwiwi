package com.accenture.tcf.bars.factory;

import java.io.File;

import com.accenture.tcf.bars.file.CSVInputFileImpl;
import com.accenture.tcf.bars.file.IInputFile;
import com.accenture.tcf.bars.file.TextInputFileImpl;

public class InputFileFactory {
	
	private static InputFileFactory inputFileFactory;
	
	private InputFileFactory() {
		// private constructor
	}
	
	public static InputFileFactory GetInstance() {
		if(inputFileFactory == null)
		{
			inputFileFactory = new InputFileFactory();
		}
		
		return inputFileFactory; 
	}
	
	public IInputFile getInputFile(File file) {
		
		String fileNameExtension = getFileExtension(file.getName());
		
		if (fileNameExtension.trim().equals("csv")){
			CSVInputFileImpl csv = new CSVInputFileImpl();
			csv.setFile(file);
			return csv;

		}else if(fileNameExtension.trim().equals("txt")) {
			TextInputFileImpl text = new TextInputFileImpl();
			text.setFile(file);
			return text;
		} 
		
		return null;
	}
	
	private String getFileExtension(String fileName) {
	    char ch;
	    int len;
	    if(fileName==null || 
	            (len = fileName.length())==0 || 
	            (ch = fileName.charAt(len-1))=='/' || ch=='\\' || //in the case of a directory
	             ch=='.' ) //in the case of . or ..
	        return "";
	    int dotInd = fileName.lastIndexOf('.'),
	        sepInd = Math.max(fileName.lastIndexOf('/'), fileName.lastIndexOf('\\'));
	    if( dotInd<=sepInd )
	        return "";
	    else
	        return fileName.substring(dotInd+1).toLowerCase();
	}
	
	
	
}
