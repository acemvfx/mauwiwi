package com.accenture.tcf.bars.factory;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.File;

import org.junit.jupiter.api.Test;

import com.accenture.tcf.bars.file.CSVInputFileImpl;
import com.accenture.tcf.bars.file.IInputFile;
import com.accenture.tcf.bars.file.TextInputFileImpl;

class InputFileFactoryTest {

	private String outputDirectory = "E:\\spring\\BillingAutomatedRequestSystem.maui.p.palad\\tests";
	@Test
	public void testGetInstance() {
		InputFileFactory inputFileFactory = InputFileFactory.GetInstance();
		
		assertNotNull(inputFileFactory);	
	}
	
	@Test
	public void testGetInputFileTxt() {
		
		InputFileFactory inputFileFactory = InputFileFactory.GetInstance();	
		assertThat(inputFileFactory.getInputFile(new File(outputDirectory.concat("BARS_001.txt"))) , instanceOf(TextInputFileImpl.class) );
	}
	
	@Test
	public void testGetInputFileCsvl() {
		InputFileFactory inputFileFactory = InputFileFactory.GetInstance();	
		assertThat(inputFileFactory.getInputFile(new File(outputDirectory.concat("BARS_001.csv"))) , instanceOf(CSVInputFileImpl.class) );
	
		
	}
	


}
