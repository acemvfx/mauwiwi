package com.accenture.tcf.bars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarsAppTests {

	@Test
	void contextLoads() {
	}

}
