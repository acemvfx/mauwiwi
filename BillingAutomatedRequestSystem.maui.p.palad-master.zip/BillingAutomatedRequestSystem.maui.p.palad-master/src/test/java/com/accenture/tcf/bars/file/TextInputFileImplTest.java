package com.accenture.tcf.bars.file;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TextInputFileImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
